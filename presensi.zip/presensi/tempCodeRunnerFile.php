<?php
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <header>
    <h3>PRESENSI MAHASISWA</h3>
    <a href="">Login</a> 
    </header> 

    <main> 
        <p>Selamat datang di website presensi</p>
    </main>

    <footer>
        <hr />
        <i>Terimakasih telah mengakses</i>
</body>
</html>